import React from "react";
import ReactDOM from "react-dom";

const Component = (props) => (
<>
<div className="p-8 bg-white flex items-center justify-center">
    
  <span className="relative z-0 inline-flex shadow-sm rounded-md">
    <button type="button" className="relative inline-flex items-center px-4 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
      Years
    </button>
    <button type="button" className="-ml-px relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
      Months
    </button>
    <button type="button" className="-ml-px relative inline-flex items-center px-4 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
      Days
    </button>
  </span>

  </div>
</>
);

ReactDOM.render(<Component/>, document.getElementById('root'));
